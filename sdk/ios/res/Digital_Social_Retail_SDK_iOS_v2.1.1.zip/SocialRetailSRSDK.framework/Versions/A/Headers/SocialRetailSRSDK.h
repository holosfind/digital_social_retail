//
//  SocialRetailSRSDK.h
//  SocialRetailSRSDK
//
//  Created by vasi on 19/02/15.
//  Copyright (c) 2015 DigitalSocialRetail. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SocialRetailSRSDK : NSObject

@end
