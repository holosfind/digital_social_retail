//
//  SRBeaconManager.h
//  SocialRetailSDK
//
//  Created by vasi on 17/02/15.
//  Copyright (c) 2015 DigitalSocialRetail. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "SRBeaconDelegate.h"
#import <CoreLocation/CoreLocation.h>

@protocol SRBeaconManagerDelegate <NSObject>
-(void)showWebViewController:(SRWebViewController *)webViewController;
@end
@interface SRBeaconManager : NSObject <CLLocationManagerDelegate>
{
    id <SRBeaconManagerDelegate> _delegate;
}
@property (nonatomic,strong) id delegate;
@property(nonatomic,strong)CLBeaconRegion * beaconRegion;
@property(nonatomic,assign)BOOL appClosed;
@property(nonatomic,assign)BOOL adViewOpened;
@property(nonatomic,assign)BOOL appInBackground;
@property(nonatomic,strong)NSString * deviceID;
@property (nonatomic,strong) NSString *uuidCurrent;
@property (nonatomic,strong) NSString *minor;
@property (nonatomic,strong) NSString * major;
@property (nonatomic,strong) NSString * timestamp;
@property (nonatomic,strong) NSString * tokenString;
@property (nonatomic,strong) NSMutableArray *offlineBeaconList;
@property (nonatomic,strong) NSString * uuidString;
@property(nonatomic,strong)CLBeaconRegion * beaconRegionT;

+ (id)sharedManager;
-(void)setBeaconDelegate:(id<SRBeaconDelegate>) beaconDelegate;
-(void)setUuidScan:(NSString *)uuidCurrent;
-(void)getOfflineBeacons;
-(void)setWSToken:(NSString *)tokenCurrent;
-(void)startBeaconDetection;
-(void)startBeconDetection __attribute__((deprecated("Please use startBeaconDetection instead of startBeconDetection")));
-(void)stopLocation;
-(void)willResignActive;
-(void)willTerminate;
-(void)didBecomeActive;
-(void)showNotificationWithUserInfo:(NSDictionary*)userInfo state:(UIApplicationState)active;
-(void)SetExtraParamsObj:(NSMutableDictionary *)extraParams __attribute__((deprecated("Please use setExtraParamsObj instead of SetExtraParamsObj")));;
-(void)setExtraParamsObj:(NSMutableDictionary *)extraParams;
-(NSDictionary*)getNearestBeaconInfo;
-(NSDictionary*)GetNearestBeacon __attribute__((deprecated("Please use getNearestBeaconInfo instead of GetNearestBeacon")));
-(BOOL)shouldICallWebServiceForBeaconUUID:(NSString *)uuid andMajor:(NSNumber *)major withMinor:(NSNumber *)minor;
-(void) setDebugMode : (BOOL) isDebugMode;
-(void) activatePreprod : (BOOL)isYes;
@end
