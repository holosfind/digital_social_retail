//
//  SocialRetailSRSDK.h
//  SocialRetailSRSDK
//
//  Created by Prabhat on 1/7/17.
//  Copyright © 2017 Emorphis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "SRBeaconDelegate.h"
#import "SRWebViewController.h"
#import "SRBeaconManager.h"
#import "SRKeychain.h"
#import "SSKeychainQuery.h"
#import "SRConstants.h"
//! Project version number for SocialRetailSRSDK.
FOUNDATION_EXPORT double SocialRetailSRSDKVersionNumber;

//! Project version string for SocialRetailSRSDK.
FOUNDATION_EXPORT const unsigned char SocialRetailSRSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SocialRetailSRSDK/PublicHeader.h>
@interface SocialRetailSRSDK : NSObject
    
@end

